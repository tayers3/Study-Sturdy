"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { FileText, Image, File, Trash2, Loader2 } from "lucide-react";

interface Note {
  id: string;
  title: string;
  content: string | null;
  file_url: string | null;
  file_type: string | null;
  created_at: string;
}

interface NotesListProps {
  notes: Note[];
  sessionId: string;
}

const fileIcons: Record<string, typeof FileText> = {
  text: FileText,
  image: Image,
  pdf: File,
};

export function NotesList({ notes, sessionId }: NotesListProps) {
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const router = useRouter();

  async function handleDelete(noteId: string) {
    if (!confirm("Are you sure you want to delete this note?")) return;
    
    setDeletingId(noteId);
    const supabase = createClient();
    
    await supabase.from("notes").delete().eq("id", noteId);
    
    setDeletingId(null);
    router.refresh();
  }

  if (notes.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>No notes added yet</p>
        <p className="text-sm">Add your first note to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {notes.map((note) => {
        const IconComponent = note.file_type 
          ? fileIcons[note.file_type] || File 
          : FileText;

        return (
          <div
            key={note.id}
            className="flex items-start gap-3 p-4 rounded-lg border border-border/50 bg-muted/30 group"
          >
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <IconComponent className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-medium truncate">{note.title}</h4>
              {note.content && (
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                  {note.content.substring(0, 150)}...
                </p>
              )}
              {note.file_url && (
                <span className="text-xs text-primary">Uploaded file</span>
              )}
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
              onClick={() => handleDelete(note.id)}
              disabled={deletingId === note.id}
            >
              {deletingId === note.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Trash2 className="w-4 h-4" />
              )}
            </Button>
          </div>
        );
      })}
    </div>
  );
}
